# 💾 Linux Automated Backup System

> Production-ready automated backup system for Linux
> Built by Sagar Savita — DevOps Engineer (LPU)

![Bash](https://img.shields.io/badge/Shell-Bash-green)
![Linux](https://img.shields.io/badge/OS-Linux-blue)
![Status](https://img.shields.io/badge/Status-Active-brightgreen)

---

## 📁 Project Structure

```
backup-project/
│
├── setup.sh          ← Step 1: Run this first!
├── basic_backup.sh   ← Step 2: Simple backup
├── pro_backup.sh     ← Step 3: Professional backup
├── restore.sh        ← Restore any backup
├── cron_setup.sh     ← Schedule automatic backups
│
├── .gitignore        ← Git rules
├── README.md         ← This file
└── logs/             ← Auto-generated log files
    └── backup.log
```

---

## ⚡ Quick Start

```bash
# 1. Clone karo
git clone https://github.com/sagarsavitahamirpur713-sketch/backup-project

# 2. Folder mein jaao
cd backup-project

# 3. Permissions do
chmod +x *.sh

# 4. Setup karo (folders + test files)
./setup.sh

# 5. Basic backup try karo
./basic_backup.sh

# 6. Professional backup chalao
./pro_backup.sh

# 7. Automatic schedule karo
./cron_setup.sh
```

---

## 📜 Script Details

### setup.sh
- Sab required folders banata hai
- Test files create karta hai ~/documents/ mein
- Script permissions set karta hai

### basic_backup.sh
- ~/documents/ ka simple backup leta hai
- ~/backups/ mein .tar.gz file save karta hai
- Success/fail clearly dikhata hai

### pro_backup.sh
- Multiple folders backup karta hai
- Disk space check karta hai pehle
- Detailed log file maintain karta hai
- 7 din purane backups auto-delete karta hai

### restore.sh
- Available backups ki numbered list dikhata hai
- User kaun sa restore karna hai choose karta hai
- ~/restored/ folder mein files wapas laata hai

### cron_setup.sh
- Automatic scheduling setup karta hai
- Multiple options — daily, every 6 hours, weekdays

---

## 🔧 Cron Format

```
* * * * * command
│ │ │ │ │
│ │ │ │ └── Weekday (0-7, 0=Sunday)
│ │ │ └──── Month   (1-12)
│ │ └────── Day      (1-31)
│ └──────── Hour     (0-23)
└────────── Minute   (0-59)

Examples:
0 23 * * *   = Rozana raat 11 baje
0 */6 * * *  = Har 6 ghante mein
0 23 * * 1-5 = Sirf Mon-Fri 11 baje
```

---

## 📊 Log Files

```bash
# Backup log dekhna
cat ~/backup-project/logs/backup.log

# Live log watch karna
tail -f ~/backup-project/logs/backup.log

# Sirf errors dekhna
grep "ERROR\|FAIL" ~/backup-project/logs/backup.log
```

---

## 👨‍💻 Author

**Sagar Savita** — 1st Year B.Tech CSE (DevOps)
Lovely Professional University, Punjab

[![LinkedIn](https://img.shields.io/badge/LinkedIn-Connect-blue)](https://linkedin.com/in/sagar-savita-595a79335)
[![GitHub](https://img.shields.io/badge/GitHub-Follow-black)](https://github.com/sagarsavitahamirpur713-sketch)
